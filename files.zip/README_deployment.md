# 🌸 Slow Life Girl

Landing page immersive pour le projet Slow Life Girl — Hala & Lamya.

## Comment déployer sur GitHub Pages

### 1. Crée un repo GitHub
- Va sur [github.com](https://github.com) → **New repository**
- Nomme-le `slowlifegirl` (ou ce que tu veux)
- Coche **Public**
- **Ne coche pas** "Add README" (on en a déjà un)
- Clique **Create repository**

### 2. Upload le fichier
Une fois le repo créé, clique sur **"uploading an existing file"** puis glisse-dépose `index.html`.
Clique **Commit changes**.

### 3. Active GitHub Pages
- Va dans **Settings** → **Pages** (menu de gauche)
- Sous *Source*, choisis **Deploy from a branch**
- Branche : **main**, dossier : **/ (root)**
- Clique **Save**

### 4. Ton lien
Après ~1 minute, ton site sera disponible à :
```
https://TON_USERNAME.github.io/slowlifegirl/
```

> Remplace `hala@slowlifegirl.com` et `lamya@slowlifegirl.com` dans le code si tu veux activer l'envoi d'emails.

---
Made with 🌸 by Hala & Lamya
